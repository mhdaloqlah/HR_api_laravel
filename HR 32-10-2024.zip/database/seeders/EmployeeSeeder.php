<?php

namespace Database\Seeders;

use App\Models\Employee;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class EmployeeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Employee::create([
            'first_name'=>'Mohammad',
            'last_name'=>'Aloqlah',
            'department_hire'=>'1',
            'department_current'=>'1',
            'job_hire'=>'1',
            'job_current'=>'1',
            'company_id'=>'1',
            'address_incompany_id'=>'2'
        ]);

        Employee::create([
            'first_name'=>'Sidra',
            'last_name'=>'Mhanna',
            'department_hire'=>'1',
            'department_current'=>'1',
            'job_hire'=>'2',
            'job_current'=>'2',
            'company_id'=>'1',
            'address_incompany_id'=>'1'
        ]);
    }
}
