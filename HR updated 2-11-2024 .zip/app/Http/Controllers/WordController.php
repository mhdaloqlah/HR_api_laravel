<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PhpOffice\PhpWord\TemplateProcessor;
use PhpOffice\PhpWord\Shared\ZipArchive;

use function Laravel\Prompts\error;

class WordController extends Controller
{
    public function mhd()
    {
        $data['message'] = 'mhd';
        return response()->json($data, 200);
    }
    public function generateWord(Request $request)
    {

        $file = '';
        if ($request->docname == 'ezdan') {
            $file = storage_path('app/public/Broker agreement_sama_ezdan.docx');
        }
        if ($request->docname == 'mayas') {
            $file = storage_path('app/public/Broker_agreement_sama_mayas.docx');
        }

        if ($file !== '') {
            // $file = new \PhpOffice\PhpWord\TemplateProcessor(storage_path('file.docx'));

            // Load the template
            $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor($file);

            // Replace placeholders with actual values
            $templateProcessor->setValue('license', $request->license);
            $templateProcessor->setValue('num', $request->num);
            $templateProcessor->setValue('postmailnum', $request->postmailnum);
            $templateProcessor->setValue('mobile', $request->mobile);
            $templateProcessor->setValue('phone', $request->phone);
            $templateProcessor->setValue('email', $request->email);
            $templateProcessor->setValue('address', $request->address);
            $templateProcessor->setValue('managername', $request->managername);
            $templateProcessor->setValue('nationality', $request->nationality);
            $templateProcessor->setValue('uaeid', $request->uaeid);
            $templateProcessor->setValue('emailmanager', $request->emailmanager);
            $templateProcessor->setValue('addressen', $request->addressen);
            $templateProcessor->setValue('managernameen', $request->managernameen);
            $templateProcessor->setValue('nationalityen', $request->nationalityen);
            $templateProcessor->setValue('companynameen', $request->companynameen);
            $templateProcessor->setValue('companyname', $request->companyname);
            $templateProcessor->setValue('city', $request->city);
            $templateProcessor->setValue('cityen', $request->cityen);
            $templateProcessor->setValue('job', $request->job);
            $templateProcessor->setValue('joben', $request->joben);


            // Save the modified document
            $fileName = 'modified_document333335.docx';
            if ($request->docname == 'ezdan') {
                $fileName = 'Broker agreement - sama ezdan.docx';
            }
            if ($request->docname == 'mayas') {
                $fileName = 'Broker agreement - sama mayas.docx';
            }
            $templateProcessor->saveAs($fileName);
            
            
            // Return the document as a download
            return response()->download($fileName)->deleteFileAfterSend(false);
        } else {
            return response()->json('Please select the correct file for company', 200);
        }
    }

    public function makedoc(Request $request)
    {
        $phpWord = new \PhpOffice\PhpWord\PhpWord();

        /* Note: any element you append to a document must reside inside of a Section. */

        // Adding an empty Section to the document...
        $section = $phpWord->addSection();
        // Adding Text element to the Section having font styled by default...
        $section->addText(
            '"Learn from yesterday, live for today, hope for tomorrow. '
                . 'The important thing is not to stop questioning." '
                . '(Albert Einstein)'
        );

        /*
         * Note: it's possible to customize font style of the Text element you add in three ways:
         * - inline;
         * - using named font style (new font style object will be implicitly created);
         * - using explicitly created font style object.
         */

        // Adding Text element with font customized inline...
        $section->addText(
            '"Great achievement is usually born of great sacrifice, '
                . 'and is never the result of selfishness." '
                . '(Napoleon Hill)',
            array('name' => 'Tahoma', 'size' => 10)
        );

        // Adding Text element with font customized using named font style...
        $fontStyleName = 'oneUserDefinedStyle';
        $phpWord->addFontStyle(
            $fontStyleName,
            array('name' => 'Tahoma', 'size' => 10, 'color' => '1B2232', 'bold' => true)
        );
        $section->addText(
            '"The greatest accomplishment is not in never falling, '
                . 'but in rising again after you fall." '
                . '(Vince Lombardi)',
            $fontStyleName
        );

        // Adding Text element with font customized using explicitly created font style object...
        $fontStyle = new \PhpOffice\PhpWord\Style\Font();
        $fontStyle->setBold(true);
        $fontStyle->setName('Tahoma');
        $fontStyle->setSize(13);
        $myTextElement = $section->addText('"Believe you can and you\'re halfway there." (Theodor Roosevelt)');
        $myTextElement->setFontStyle($fontStyle);

        // Saving the document as OOXML file...
        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
        $objWriter->save('helloWorld.docx');

        // Saving the document as ODF file...
        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'ODText');
        $objWriter->save('helloWorld.odt');

        // Saving the document as HTML file...
        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'HTML');
        $objWriter->save('helloWorld.html');
    }
}
